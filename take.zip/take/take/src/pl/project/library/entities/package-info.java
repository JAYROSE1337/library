/**
 * Library entities.
 * @author Jakub Porebski, Maciej Jaros
 */

package pl.project.library.entities;