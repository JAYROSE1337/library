/**
 * Package contains all classes which are responsible for application functionalities
 * @author Maciej Jaros, Jakub Por�bski
 */
package pl.project.library.app;